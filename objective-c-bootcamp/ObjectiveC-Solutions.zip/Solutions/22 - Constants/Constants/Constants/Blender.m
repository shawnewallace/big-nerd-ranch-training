//
//  Blender.m
//  Constants
//
//  Created by Mark Fenoglio on 6/12/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import "Blender.h"


@implementation Blender

- (void)setSpeed:(BlenderSpeed)s
{
	speed = s;
}

@end
