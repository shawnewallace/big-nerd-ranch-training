//
//  main.m
//  Constants
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Blender.h"

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		NSLog(@"\u03c0 is %f", M_PI);
		NSLog(@"%d is larger", MAX(10,12));
		
		NSLocale *here = [NSLocale currentLocale];
		NSString *currency = [here objectForKey:NSLocaleCurrencyCode];
		NSLog(@"Money is %@", currency);
	}
	
    return 0;
}

