//
//  Blender.h
//  Constants
//
//  Created by Mark Fenoglio on 6/12/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
	BlenderSpeedStir = 1,
	BlenderSpeedChop = 2,
	BlenderSpeedLiquify = 5,
	BlenderSpeedPulse = 9,
	BlenderSpeedCrush = 15	
} BlenderSpeed;

@interface Blender : NSObject
{
    BlenderSpeed speed;
}

- (void)setSpeed:(BlenderSpeed)speed;

@end
