//
//  main.m
//  KitchenSink
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		// Array to hold everything that will go into the Property List file
		NSMutableArray *pList = [[NSMutableArray alloc] init];
		
		// Array to go into the property list
		NSArray *mohs = [NSArray arrayWithObjects:@"Talc", @"Gypsum", @"Calcite", @"Fluorite", @"Apatite", @"Feldspar", @"Quartz", @"Topaz", @"Corundum", @"Diamond", nil];
		[pList addObject:mohs];
		
		// Dictionary to go into the property list
		NSMutableDictionary *collection = [[NSMutableDictionary alloc] init];
		[collection setObject:@"Rutile" forKey:@"name"];
		[collection setObject:@"TiO2" forKey:@"formula"];
		[pList addObject:collection];
		
		// String to go into the property list
		[pList addObject:@"Mineral Madness!"];
		
		// Data added to the property list
		
		// Date added to the property list
		[pList addObject:[NSDate date]];
		
		// Integer added to the property list
		[pList addObject:[NSNumber numberWithInt:42]];
		
		// Float added to the property list
		[pList addObject:[NSNumber numberWithFloat:3.14159]];
		
		// Boolean added to the property list
		[pList addObject:[NSNumber numberWithBool:true]];
		
		// Save the pList
		[pList writeToFile:@"/tmp/kitchen-sink.plist" atomically:YES];
 	    
	}
    return 0;
}

