//
//  Appliance.m
//  26
//
//  Created by Mark Fenoglio on 4/3/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import "Appliance.h"


@implementation Appliance

@synthesize productName, voltage;

- (id)init
{
    return [self initWithProductName:@"Unknown"];
}

// Convenience Initializer
- (id)initWithProductName:(NSString *)pn
{
	// Call NSObject's init method
    self = [super init];
    
	if (self) {
		
		// Set the product name
		[self setProductName:pn];
		
		// Give voltage a starting value
		[self setVoltage: 120];
	}
    
    return self;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"<%@: %d volts>", productName, voltage];   
}

@end
