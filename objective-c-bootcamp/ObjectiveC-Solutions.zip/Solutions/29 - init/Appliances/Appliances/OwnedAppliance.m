//
//  OwnedAppliance.m
//  26
//
//  Created by Mark Fenoglio on 4/3/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import "OwnedAppliance.h"


@implementation OwnedAppliance

- (id)initWithProductName:(NSString *)pn
           firstOwnerName:(NSString *)n
{
    self = [super initWithProductName:pn];
    
	if (self) {
		// Make a set to hold owner names
		ownerNames = [[NSMutableSet alloc] init];
		
		// Is the first owner name non-nil?
		if (n) {
			[ownerNames addObject:n];
		}
	}
    
	// Return a pointer to the new object
    return self;
}

- (id)initWithProductName:(NSString *)pn
{
    return [self initWithProductName:pn
                      firstOwnerName:nil];
}

- (void)addOwnerName:(NSString *)n
{
    [ownerNames addObject:n];
}

- (void)removeOwnerName:(NSString *)n
{
    [ownerNames removeObject:n];
}

@end
