//
//  BNRDocument.h
//  TahDoodle
//
//  Created by Mark Fenoglio on 10/21/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BNRDocument : NSDocument
{
	NSMutableArray *todoItems;
    IBOutlet NSTableView *itemTableView;
}

- (IBAction)createNewItem:(id)sender;
- (IBAction)deleteSelectedItem:(id)sender;

@end
