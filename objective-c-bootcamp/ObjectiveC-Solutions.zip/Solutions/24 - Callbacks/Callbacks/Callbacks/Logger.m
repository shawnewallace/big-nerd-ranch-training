//
//  Logger.m
//  21
//
//  Created by Mark Fenoglio on 4/1/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import "Logger.h"


@implementation Logger

#pragma mark Timer

- (void)sayOuch:(NSTimer *)t
{
	NSLog(@"Ouch!");
}

#pragma mark NSURLConnection Delegate

// Called each time a chunk of data arrives
- (void)connection:(NSURLConnection *)connection
	didReceiveData:(NSData *)data
{
	NSLog(@"received %lu bytes", [data length]);
	
	if (! incomingData) {
		incomingData = [[NSMutableData alloc] init];
	}
	
	[incomingData appendData:data];
}

// Called when last chunk of data has been processed
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSLog(@"Got it all!");
	NSString *string = [[NSString alloc] initWithData:incomingData
									   encoding:NSUTF8StringEncoding];
	incomingData = nil;
	NSLog(@"string has %lu characters", [string length]);
	
	// Uncomment the next line to see the entire fetched string
	// NSLog(@"The whole string is %@", string);
}

// Called if the fetch fails 
- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error
{
	NSLog(@"connection failed: %@", [error localizedDescription]);
	incomingData = nil;
}

#pragma mark NSNotificationCenter Notifications

- (void)zoneChange:(NSNotification *)note
{
	NSLog(@"The system time zone has changed!");
}

#pragma mark Destruction

- (void)dealloc
{
	// Un-register with the notification center 
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
