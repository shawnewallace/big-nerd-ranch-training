//
//  Logger.h
//  21
//
//  Created by Mark Fenoglio on 4/1/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Logger : NSObject <NSURLConnectionDelegate, NSURLConnectionDataDelegate>
{
    NSMutableData *incomingData;
}

- (void)sayOuch:(NSTimer *)t;

@end
