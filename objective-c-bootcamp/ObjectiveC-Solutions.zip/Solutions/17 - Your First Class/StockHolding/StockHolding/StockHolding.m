//
//  StockHolding.m
//  StockHolding
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import "StockHolding.h"

@implementation StockHolding

@synthesize purchaseSharePrice, currentSharePrice, numberOfShares;

- (float)costInDollars
{
	return numberOfShares * purchaseSharePrice;
}

- (float)valueInDollars
{
	return numberOfShares * currentSharePrice;
}


@end
