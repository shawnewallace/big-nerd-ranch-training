//
//  Person.m
//  BMITime
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import "Person.h"

@implementation Person

- (float)heightInMeters
{
	return heightInMeters;
}

- (void)setHeightInMeters:(float)h
{
	heightInMeters = h;
}

- (int)weightInKilos
{
	return weightInKilos;
}

- (void)setWeightInKilos:(int)w
{
	weightInKilos = w;
}

- (float)bodyMassIndex
{
	return weightInKilos / (heightInMeters * heightInMeters);
}


@end
