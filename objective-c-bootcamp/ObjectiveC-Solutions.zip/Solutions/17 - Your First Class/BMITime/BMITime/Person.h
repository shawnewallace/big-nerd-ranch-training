//
//  Person.h
//  BMITime
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
	// It has two instance variables
	float heightInMeters;
	int weightInKilos;
}

// You will be able to set those instance variables using these methods
- (float)heightInMeters;
- (void)setHeightInMeters:(float)h;
- (int)weightInKilos;
- (void)setWeightInKilos:(int)w;

// This method calculates the Body Mass Index
- (float)bodyMassIndex;

@end
