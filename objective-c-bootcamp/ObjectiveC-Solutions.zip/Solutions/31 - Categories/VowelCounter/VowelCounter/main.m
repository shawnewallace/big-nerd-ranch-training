//
//  main.m
//  VowelCounter
//
//  Created by Mark Fenoglio on 9/16/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+VowelCounting.h"

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		NSString *string = @"Welcome to Big Nerd Ranch!";
		NSLog(@"%@ has %d vowels", string, [string vowelCount]);
	}
    return 0;
}

