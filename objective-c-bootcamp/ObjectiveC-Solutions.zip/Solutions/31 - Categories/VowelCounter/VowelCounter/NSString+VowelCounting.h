//
//  NSString+VowelCounting.h
//  VowelCounter
//
//  Created by Mark Fenoglio on 9/16/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (VowelCounting)

- (int)vowelCount;

@end
