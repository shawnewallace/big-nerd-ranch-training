//
//  Asset.m
//  BMITime
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import "Asset.h"

@implementation Asset

@synthesize label, resaleValue, holder;

- (NSString *)description
{
	// Is holder non-nil?
	if ([self holder]) {
		return [NSString stringWithFormat:@"<%@: $%d assigned to %@>", [self label], [self resaleValue], [self holder]];
	} else {
		return [NSString stringWithFormat:@"<%@: $%d unassigned>", [self label], [self resaleValue]];
	}
}

- (void)dealloc
{
	NSLog(@"deallocation %@", self);
}

@end
