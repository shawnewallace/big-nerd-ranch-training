//
//  main.m
//  MyComputerName
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		NSHost *host = [NSHost currentHost];
		NSLog(@"%@", [host localizedName]);
		NSLog(@"%@", [host name]);
	    
	}
    return 0;
}

