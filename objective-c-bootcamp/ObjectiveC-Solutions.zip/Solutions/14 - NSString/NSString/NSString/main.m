//
//  main.m
//  NSString
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		// Using NSString objects
		NSString *lament = @"Why me?!";
		NSLog(@"%@", lament);
		
		NSString *x = [NSString stringWithFormat:@"The best number is %d", 5];
		NSUInteger charCount = [x length];
		NSLog(@"%@ is %lu characters long", x, charCount);
		
		if ([lament isEqual:x]) {
			NSLog(@"%@ and %@ are equal", lament, x);
		}
		
		// Using a C approach
		char *cLament = "Why me?!";
		char *cX;
		asprintf(&cX, "The best number is %d", 5);
		size_t cCharCount = strlen(cX);
		printf(stderr, "%s is %lu characters long\n", cX, cCharCount);
		if (strcmp(cLament, cX) == 0) {
			printf(stderr, "%s and %s are equal\n", cLament, cX);
		}
	    
	}
    return 0;
}

