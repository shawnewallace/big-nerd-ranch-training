//
//  Appliance.h
//  26
//
//  Created by Mark Fenoglio on 4/3/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Appliance : NSObject
{
    NSString *productName;
    int voltage;
}

//@property (copy) NSString *productName;
@property int voltage;

// Designated Initializer
- (id)initWithProductName:(NSString *)pn;

@end
