//
//  OwnedAppliance.h
//  26
//
//  Created by Mark Fenoglio on 4/3/11.
//  Copyright 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Appliance.h"

@interface OwnedAppliance : Appliance
{
    NSMutableSet *ownerNames;
}

// Designated Initializer
- (id)initWithProductName:(NSString *)pn
           firstOwnerName:(NSString *)n;

- (void)addOwnerName:(NSString *)n;
- (void)removeOwnerName:(NSString *)n;

@end
