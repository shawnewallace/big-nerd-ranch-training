//
//  main.m
//  StockHolding
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ForeignStockHolding.h"

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		StockHolding *one = [[StockHolding alloc] init];
		[one setNumberOfShares:40];
		[one setPurchaseSharePrice:2.30];
		[one setCurrentSharePrice:4.50];
		
		StockHolding *two = [[StockHolding alloc] init];
		[two setNumberOfShares:90];
		[two setPurchaseSharePrice:12.19];
		[two setCurrentSharePrice:10.56];
    
		ForeignStockHolding *three = [[ForeignStockHolding alloc] init];
		[three setNumberOfShares:210];
		[three setPurchaseSharePrice:45.10];
		[three setCurrentSharePrice:49.51];
		[three setConversionRate:0.94];
		
		NSArray *portfolio = [NSArray arrayWithObjects:one, two, three, nil];
		
		for (StockHolding *stock in portfolio) {
			NSLog(@"Value = $%.2f ", [stock valueInDollars]);
		}
		
		// A little fun with portfolio value
		float gainLoss = 0;
		for (StockHolding *stock in portfolio) {
			gainLoss += [stock valueInDollars] - [stock costInDollars];
		}
		
		if (gainLoss > 0) {
			NSLog(@"My portfolio has gained $%.2f.", gainLoss);
		} else {
			NSLog(@"My portfolio has lost $%.2f.", -gainLoss);
		}
	}
    return 0;
}

