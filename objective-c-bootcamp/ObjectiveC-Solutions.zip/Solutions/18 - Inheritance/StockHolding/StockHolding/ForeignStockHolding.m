//
//  ForeignStockHolding.m
//  StockHolding
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import "ForeignStockHolding.h"

@implementation ForeignStockHolding

@synthesize conversionRate;

- (float)costInDollars
{
	return numberOfShares * purchaseSharePrice * conversionRate;
}

- (float)valueInDollars
{
	return numberOfShares * currentSharePrice * conversionRate;
}

@end
