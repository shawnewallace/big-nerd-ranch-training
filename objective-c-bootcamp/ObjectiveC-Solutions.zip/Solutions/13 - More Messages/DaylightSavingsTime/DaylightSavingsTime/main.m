//
//  main.m
//  DaylightSavingsTime
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		NSTimeZone *tz = [NSTimeZone systemTimeZone];
		if ([tz isDaylightSavingTime] == YES) {
			NSLog(@"Daylight savings time is silly. We should get rid of it.");
		} else {
			NSLog(@"No Daylight saving time!");
		}
	    
	}
    return 0;
}





