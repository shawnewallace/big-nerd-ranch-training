//
//  Portfolio.h
//  StockHolding
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>
@class StockHolding;

@interface Portfolio : NSObject
{
	NSMutableArray *stocks;
}

- (void)addStockHolding:(StockHolding *)s;
- (float)value;

@end
