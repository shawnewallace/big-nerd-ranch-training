//
//  Portfolio.m
//  StockHolding
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import "Portfolio.h"
#import "StockHolding.h"

@implementation Portfolio

- (void)addStockHolding:(StockHolding *)s
{
	if (! stocks) {
		stocks = [[NSMutableArray alloc] init];
	}
	[stocks addObject:s];
}

- (float)value
{
	unsigned int sum = 0;
	for (StockHolding *s in stocks) {
		sum += [s valueInDollars];
	}
	return sum;
}

@end





