//
//  main.m
//  WordsAndNames
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		// CHALLENGE INTRODUCTION: FINDING "AA"
		
		// Read in a file as a huge string (ignoring the possibility of an error)
		NSString *nameString = [NSString stringWithContentsOfFile:@"/usr/share/dict/propernames" 
														 encoding:NSUTF8StringEncoding 
															error:NULL];
		
		// Break it into an array of strings
		NSArray *names = [nameString componentsSeparatedByString:@"\n"];
		
		// Go through the array one string at a time
		for (NSString *n in names) {
			
			// Look for the string "aa" in a case-insensitive manner
			NSRange r = [n rangeOfString:@"AA"
								 options:NSCaseInsensitiveSearch];
			
			// Was it found?
			if (r.location != NSNotFound) {
				NSLog(@"%@", n);
			}
		}
		
		// REAL CHALLENGE: FIND COMMON PROPER NAMES THAT ARE ALSO REGULAR WORDS
		
		// Read in the proper names
		NSString *properString = [NSString stringWithContentsOfFile:@"/usr/share/dict/propernames" 
														   encoding:NSUTF8StringEncoding 
															  error:NULL];
		NSArray *properNames = [properString componentsSeparatedByString:@"\n"];
	    
		// Read in the regular words
		NSString *regularString = [NSString stringWithContentsOfFile:@"/usr/share/dict/words" 
															encoding:NSUTF8StringEncoding 
															   error:NULL];
		
		for (NSString *n in properNames) {
			
			// Look for the string "aa" in a case-insensitive manner
			NSRange r = [regularString rangeOfString:n
											 options:NSCaseInsensitiveSearch];
			
			// Was it found?
			if (r.location != NSNotFound) {
				NSLog(@"%@", n);
			}
	}
		
	}
    return 0;
}

