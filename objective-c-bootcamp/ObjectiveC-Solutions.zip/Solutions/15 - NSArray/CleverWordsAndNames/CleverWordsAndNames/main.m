//
//  main.m
//  CleverWordsAndNames
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		// Read in a file as a huge string (ignoring the possibility of an error)
		NSString *nameString = [NSString stringWithContentsOfFile:@"/usr/share/dict/propernames" 
														 encoding:NSUTF8StringEncoding 
															error:NULL];
		
		// Break it into an array of strings
		NSArray *names = [nameString componentsSeparatedByString:@"\n"];
		
		// Read the words file into a string
		NSString *wordString = [NSString stringWithContentsOfFile:@"/usr/share/dict/words" 
														 encoding:NSUTF8StringEncoding 
															error:NULL];
		
		/*
		 Getting a bit clever here: it turns out that the words file contains a lot
		 of proper names: not *all* the proper names in /usr/share/dict/propernames,
		 but a lot of them.
		 
		 The quickest way to remove one list (array of objects) from another is to
		 use sets.
		 */
		
		// Break proper names into an array of strings
		NSArray *wordsWithProperNames = [wordString componentsSeparatedByString:@"\n"];
		
		// Eliminate proper names from the words array
		NSMutableSet *wordsSet = [NSMutableSet setWithArray:wordsWithProperNames];
		[wordsSet minusSet:[NSSet setWithArray:names]];
		NSArray *words = [wordsSet allObjects];
		
		/*
		// BRUTE FORCE: Double loop (Works but SLOW)
		int numMatches = 0;
		for (NSString *n in names) {
			for (NSString *w in words) {
				if ([n caseInsensitiveCompare:w] == NSOrderedSame) {
					NSLog(@"%@ == %@", n, w);
					numMatches++;
					break;
				}
			}
		}
		NSLog(@"Matches found: %d", numMatches);
		*/
		// ALTERNATIVE APPROACH: Use sets to identify the matches
		
		// Make all the names lowercase
		NSMutableArray *lowercaseNames = [NSMutableArray arrayWithCapacity:[names count]];
		for (NSString *n in names) {
			[lowercaseNames addObject:[n lowercaseString]];
		}
		
		NSMutableSet *intersection = [NSMutableSet setWithArray:lowercaseNames];
		[intersection intersectSet:[NSSet setWithArray:words]];
		
		NSMutableArray *matches = [[intersection allObjects] mutableCopy];
		[matches sortUsingSelector:@selector(caseInsensitiveCompare:)];
		
		for (NSString *match in matches) {
			NSLog(@"%@", match);
		}
		NSLog(@"Matches found: %lu", [matches count]);
	}
    return 0;
}

