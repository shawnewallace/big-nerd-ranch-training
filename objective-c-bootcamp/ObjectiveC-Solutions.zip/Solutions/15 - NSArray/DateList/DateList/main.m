//
//  main.m
//  DateList
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SECONDS_IN_DAY 24.0 * 60.0 * 60.0

int main (int argc, const char * argv[])
{

	@autoreleasepool {
	    
		// Create three NSDate objects
		NSDate *now = [NSDate date]; 
		NSDate *tomorrow = [now dateByAddingTimeInterval:24.0 * 60.0 * 60.0]; 
		NSDate *yesterday = [now dateByAddingTimeInterval:-24.0 * 60.0 * 60.0];
		
		// Create an array containing all three (nil terminates the list)
		NSArray *dateList = [NSArray arrayWithObjects:now, tomorrow, yesterday, nil];
		
		// How many dates are there?
		//unsigned long dateCount = [dateList count];
		NSLog(@"There are %lu dates", [dateList count]);
		
		// Print a couple 
		NSLog(@"The first date is %@", [dateList objectAtIndex:0]);
		NSLog(@"The third date is %@", [dateList objectAtIndex:2]);
		
		// Using a for loop to display the dates
		NSUInteger dateCount = [dateList count];
		for (int i = 0; i < dateCount; i++) {
			NSDate *d = [dateList objectAtIndex:i];
			NSLog(@"Here is a date: %@", d);
		}
		
		// Using fast enumeration to display the dates
		for (NSDate *d in dateList) {
			NSLog(@"Here is a date: %@", d);
		}
		
		// Create a mutable array instead
		NSMutableArray *dateArray = [NSMutableArray array];
		
		// Add the dates to the array
		[dateArray addObject:now];
		[dateArray addObject:tomorrow];
		
		// Put yesterday at the beginning of the array
		[dateArray insertObject:yesterday
						atIndex:0];
		
		// Display the dates in the array
		for (NSDate *d in dateArray) {
			NSLog(@"Here is a date: %@", d);
		}
		
		// Remove yesterday
		[dateArray removeObjectAtIndex:0];
		NSLog(@"Now the first date is %@", [dateArray objectAtIndex:0]);
	    
	}
    return 0;
}

