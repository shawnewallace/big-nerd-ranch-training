//
//  main.m
//  iTahDoodle
//
//  Created by Mark Fenoglio on 10/21/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BNRAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([BNRAppDelegate class]));
	}
}
