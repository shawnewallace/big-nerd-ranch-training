//
//  BNRAppDelegate.h
//  iTahDoodle
//
//  Created by Mark Fenoglio on 10/21/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <UIKit/UIKit.h>

// Declare a helper function that we will use to get a path to the location on disk where we can save the do-lo list
NSString *docPath(void);

@interface BNRAppDelegate : UIResponder <UIApplicationDelegate, UITableViewDataSource>
{
	UITableView *taskTable;
	UITextField *taskField;
	UIButton *insertButton;
	
	NSMutableArray *tasks;
}

@property (strong, nonatomic) UIWindow *window;

- (void)addTask:(id)sender;

@end
