//
//  main.m
//  TimeAfterTimeChallenge
//
//  Created by Mark Fenoglio on 9/15/11.
//  Copyright (c) 2011 Big Nerd Ranch. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{
	@autoreleasepool {
		NSDateComponents *components = [[NSDateComponents alloc] init];
		[components setYear:1967];
		[components setMonth:12];
		[components setDay:26];
		[components setHour:1];
		
		NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
		NSDate *dateOfBirth = [gregorian dateFromComponents:components];
		
		// NSTimeInterval is just a double (a typedef is used)
		NSTimeInterval timeSinceBirth = [[NSDate date] timeIntervalSinceDate:dateOfBirth];
		
		NSLog(@"Seconds since birth = %.0f", timeSinceBirth);
		NSLog(@"Minutes since birth = %.0f", roundf(timeSinceBirth/60.0));
		NSLog(@"Hours since birth = %f", timeSinceBirth/(60.0 * 60.0));
		NSLog(@"Days since birth = %f", timeSinceBirth/(24.0 * 60.0 * 60.0));
		NSLog(@"Years since birth = %f", timeSinceBirth/(365.0 * 24.0 * 60.0 * 60.0));
		
		NSLog(@"My birthday is %@", dateOfBirth);
	}
    return 0;
}

